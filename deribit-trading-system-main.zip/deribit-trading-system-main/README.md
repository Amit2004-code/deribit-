Deribit Trading System
Overview

Author: Amit Kumar

Deribit Trading System is a high-performance order execution and management platform that operates through a command-line interface.
It utilizes a WebSocket client to connect to the Deribit TESTNET and provides powerful trading functionality, including managing portfolios, orders, and subscriptions with advanced features.

Features

Secure WebSocket-based trading interface
Command-line trading operations
Support for various order types
API authentication and session management
Real-time open orders management
Order modification and cancellation
Subscription to market streams
Tech Stack





Prerequisites

C++ Compiler (g++)
CMake
Boost Libraries
OpenSSL
Git
Readline Library
Installation Guide

macOS
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install cmake gcc boost openssl git readline
Linux (Ubuntu/Debian)
sudo apt update
sudo apt install cmake gcc libboost-all-dev libssl-dev git libreadline-dev
Windows
Install CMake, Git, Visual Studio Build Tools (C++ workload)
Download Boost and OpenSSL binaries
Project Setup

Clone the repository:
git clone <your-repo-url>
cd deribit-trading-system
Create a build directory:
mkdir build
cd build
Build the project:
cmake ..
cmake --build .
Run the application:
./deribit_trader
Application Usage

Basic Commands
help / man — Display all supported commands
connect <URI> — Connect to a WebSocket server
Deribit connect — Quick connect to Deribit TESTNET
send <id> <message> — Send a message through a specific connection
show <id> — Display connection metadata
show_messages <id> — Display all messages for a connection
latency_report — Generate a latency report
reset_report — Clear the latency data
close <id> [code] [reason] — Close a WebSocket connection
view_subscriptions — View active subscriptions
view_stream — Stream market data for subscribed symbols
quit / exit — Exit the application
Deribit API Commands
Authorization:
Deribit <id> authorize <client_id> <client_secret> [-s]
Place Buy Order:
Deribit <id> buy <instrument> <transaction_name>
Place Sell Order:
Deribit <id> sell <instrument> <transaction_name>
Modify Order:
Deribit <id> modify <order_id>
Cancel Order:
Deribit <id> cancel <order_id>
Deribit <id> cancel_all
View Positions and Open Orders:
Deribit <id> positions [currency] [kind]
Deribit <id> get_open_orders [currency] [instrument] [label]
Order Book and Market Data:
Deribit <id> orderbook <instrument> [depth]
Deribit <id> subscribe [symbol]
Deribit <id> unsubscribe [symbol]
Deribit <id> unsubscribe_all
Supported Order Types


Order Type	Command Flag
Limit	limit
Stop Limit	stop_limit
Take Limit	take_limit
Market	market
Stop Market	stop_market
Take Market	take_market
Market Limit	market_limit
Trailing Stop	trailing_stop
Time In Force Options


Time in Force	Flag
Good Till Cancelled	good_til_cancelled
Good Till Day	good_til_day
Fill or Kill	fill_or_kill
Immediate or Cancel	immediate_or_cancel
Project Structure

├── include
│   ├── api/
│   ├── authentication/
│   ├── json/
│   ├── utils/
│   ├── latency/
│   └── websocket/
├── src
│   ├── api/
│   ├── authentication/
│   ├── utils/
│   ├── latency/
│   ├── websocket/
│   └── main.cpp
├── build/
├── scripts/
├── README.md
└── CMakeLists.txt
Development Tips

Refer to Deribit API Documentation for building new features.
Test API Calls on the Deribit API Console.
Experiment safely using Deribit Testnet accounts.
Contribution

Contributions are welcome!
Feel free to fork the repository, create a branch, make your changes, and submit a pull request.

License

This project is licensed under the MIT License.
© 2025 Amit Kumar
